#!/bin/bash


wget http://client/~james/rules/nuRules -O /etc/firewall-rules.txt


iptables -F


iptables -P INPUT DROP


while read line; do
  ip=$(echo $line | awk '{print $1}')
  ports=$(echo $line | awk '{$1=""; print $0}')
  for port in $ports; do
    iptables -A INPUT -s $ip -p tcp --dport $port -j ACCEPT
  done
done < /etc/firewall-rules.txt
echo "Script executed successfully."

